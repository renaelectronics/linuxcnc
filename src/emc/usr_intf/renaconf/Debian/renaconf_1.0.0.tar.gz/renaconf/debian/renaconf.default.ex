# Defaults for renaconf initscript
# sourced by /etc/init.d/renaconf
# installed at /etc/default/renaconf by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
