?package(renaconf):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="renaconf" command="/usr/bin/renaconf"
